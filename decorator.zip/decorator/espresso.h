#pragma once
#include "beverage.h"

class Espresso : public Beverage {
public:
       Espresso();
       double cost();
};       
