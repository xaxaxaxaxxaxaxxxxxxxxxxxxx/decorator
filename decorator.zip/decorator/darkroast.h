#pragma once
#include "beverage.h"

class DarkRoast : public Beverage {
public:
       DarkRoast();
       double cost();
};        
