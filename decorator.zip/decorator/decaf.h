#pragma once
#include "beverage.h"

class Decaf : public Beverage {
public:
       Decaf();
       double cost();
};       
