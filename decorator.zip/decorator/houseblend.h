#pragma once
#include "beverage.h"

class HouseBlend : public Beverage {
public:
       HouseBlend();
       double cost();
};                   
